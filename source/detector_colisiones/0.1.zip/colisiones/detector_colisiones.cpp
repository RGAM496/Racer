#include "detector_colisiones.h"


namespace urjr
{
	namespace Colision
	{

		typedef bool (*FuncionDeteccion) (ModuloDetector*, ModuloDetector*);


		bool ModuloDetector::colisiona_con (ModuloDetector *objeto)
		{
			return true;
		}

	}
}