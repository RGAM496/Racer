#include "colision_paralelepipedo.h"


namespace urjr
{
	namespace Colision
	{

		void Paralelepipedo::base (Rectangulo *r)
		{
			r->x[MIN] = centro_base[X] - semilado;
			r->x[MAX] = centro_base[X] + semilado;
			r->y[MIN] = centro_base[Z] - semilado;
			r->y[MAX] = centro_base[Z] + semilado;
		}

		void Paralelepipedo::altura (Intervalo &i)
		{
			i[MIN] = centro_base[Y];
			i[MAX] = centro_base[Y] + 2.0 * semilado;
		}

	}
}