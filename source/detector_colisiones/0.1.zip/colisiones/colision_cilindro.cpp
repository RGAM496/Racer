#include "colision_cilindro.h"


namespace urjr
{
	namespace Colision
	{

		void Cilindro::base (Circulo *r)
		{
			r->centro[X] = centro_base[X];
			r->centro[Y] = centro_base[Z];
		}

		void Cilindro::altura (Intervalo &i)
		{
			i[MIN] = centro_base[Y];
			i[MAX] = centro_base[Y] + altura;
		}

	}
}