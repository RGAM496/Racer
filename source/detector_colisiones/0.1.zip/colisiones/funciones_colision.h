#ifndef FUNCIONES_COLISION_H
#define FUNCIONES_COLISION_H

#include "geometria_colisiones.h"
#include "colision_paralelepipedo.h"
#include "colision_cilindro.h"
#include "colision_piramide.h"


namespace urjr
{
	namespace Colision
	{

		bool colisionan (Paralelepipedo *, Paralelepipedo *);
		bool colisionan (Cilindro *, Cilindro *);

	}
}


#endif // FUNCIONES_COLISION_H