#ifndef DETECTOR_COLISIONES_H
#define DETECTOR_COLISIONES_H


namespace urjr
{
	namespace Colision
	{

		enum Forma {
			PARALELEPIPEDO,
			CILINDRO,
			PIRAMIDE,

			CONTEO_TOTAL
		};


		/***************************************
		* Interfaz del detector de colisiones. *
		***************************************/

		class ModuloDetector
		{
			public:

				// Devuelve el tipo de colisión correspondiente.
				virtual Forma tipo_colision () = 0;

				// Devuelve true si este objeto y el referido están en una situación de colisión.
				bool colisiona_con (ModuloDetector *);
		};

		template <Forma f_colision>
		class Detector : public ModuloDetector
		{
			private:

				Forma forma_colision;

			public:

				Forma tipo_colision() {
					return forma_colision;
				}

				// Constructor.
				Detector () {
					forma_colision = f_colision;
				}
		};

	}
}


#endif // DETECTOR_COLISIONES_H
