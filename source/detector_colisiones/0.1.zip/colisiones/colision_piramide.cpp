#include "colision_piramide.h"


namespace urjr
{
	namespace Colision
	{

		void Piramide::base (Rectangulo *r)
		{
			generar_base (r, 0);
		}

		void Piramide::base (Rectangulo *r, Longitud h)
		{
			Longitud sl = (1.0 - h / altura) * semilado;

			generar_base (r, sl);
		}

		void Piramide::altura (Intervalo &i)
		{
			i[MIN] = centro_base[Y];
			i[MAX] = centro_base[Y] + altura;
		}


		void Piramide::generar_base (Rectangulo *r, Longitud sl)
		{
			r->x[MIN] = centro_base[X] - sl;
			r->x[MAX] = centro_base[X] + sl;
			r->y[MIN] = centro_base[Z] - sl;
			r->y[MAX] = centro_base[Z] + sl;
		}
	}
}