#include <cstdlib>
#include <iostream>
#include "../detector_colisiones.h"
#include "../geometria_colisiones.h"
#include "../colision_paralelepipedo.h"

class ParalelepipedoColision : public urjr::Colision::Detector<urjr::Colision::Forma::PARALELEPIPEDO>
{
};

/*class ParalelepipedoCirculo : public urjr::Colision::Detector<urjr::Colision::Forma::CILINDRO>
{
};*/

typedef urjr::Colision::Detector<urjr::Colision::Forma::CILINDRO> CilindroColision;

template <size_t N>
void copiar (double p1[N], double p2[N])
{
	std:: cout << "N = " << N << std::endl;
	for (size_t i = 0; i < N; i++)
		p1[i] = p2[i];
}

std::ostream& operator << (std::ostream &os, urjr::Colision::Punto2D p)
{
	const size_t N = 2;
	os << "(" << p[0];
	for (size_t i = 1; i < N; i++)
		os << ", " << p[i];
	os << ")";
	return os;
}


int main()
{
	ParalelepipedoColision p;
	CilindroColision c;
	std::cout << p.tipo_colision() << std::endl;
	std::cout << (int)c.tipo_colision() << std::endl;
	std::cout << (int)urjr::Colision::CILINDRO << (int)urjr::Colision::PARALELEPIPEDO << std::endl;
	
	double d[2] = {3, -2.0};
	urjr::Colision::Punto2D pt, pt2;
	urjr::Colision::Coordenada co;
	urjr::Colision::Longitud lo;
	
	lo = 1;
	co = -1;
	pt2 = d;//{-5.2, 4};
	urjr::Colision::Punto2D pt3 (d);
	
	std::cout << (sizeof(pt)/sizeof(double)) << std::endl;
	std::cout << "c = " << co << std::endl;
	std::cout << "l = " << lo << std::endl;
	std::cout << pt << std::endl;
	pt = pt2;
	std::cout << pt3 << std::endl;
	
	urjr::Colision::Paralelepipedo par;
	
	system("pause");
	return 0;
}
