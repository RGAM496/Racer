#ifndef COLISION_CILINDRO_H
#define COLISION_CILINDRO_H

#include "detector_colisiones.h"
#include "geometria_colisiones.h"


namespace urjr
{
	namespace Colision
	{

		class Cilindro : public Detector <Forma::CILINDRO>
		{
			protected:

				Punto3D
					centro_base;

				Longitud
					radio_base,
					altura;

			public:

				void base (Circulo *);
				void altura (Intervalo &);
		};

	}
}


#endif // COLISION_CILINDRO_H