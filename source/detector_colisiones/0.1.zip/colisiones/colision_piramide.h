#ifndef COLISION_PIRAMIDE_H
#define COLISION_PIRAMIDE_H

#include "detector_colisiones.h"
#include "geometria_colisiones.h"


namespace urjr
{
	namespace Colision
	{

		class Piramide : public Detector <Forma::PIRAMIDE>
		{
			protected:

				Punto3D
					centro_base;

				Longitud
					semilado,
					altura;

				// Calcula las dimensiones del rectángulo a partir del semilado "sl".
				generar_base (Rectangulo *, Longitud sl);

			public:

				void base (Rectangulo *);
				void base (Rectangulo *, Longitud h);
				void altura (Intervalo &);
		};

	}
}


#endif // COLISION_PIRAMIDE_H