#ifndef COLISION_PARALELEPIPEDO_H
#define COLISION_PARALELEPIPEDO_H

#include "detector_colisiones.h"
#include "geometria_colisiones.h"


namespace urjr
{
	namespace Colision
	{

		class Paralelepipedo : public Detector <Forma::PARALELEPIPEDO>
		{
			protected:

				Punto3D
					centro_base;

				Longitud
					semilado;

			public:

				void base (Rectangulo *);
				void altura (Intervalo &);
		};

	}
}


#endif // COLISION_PARALELEPIPEDO_H