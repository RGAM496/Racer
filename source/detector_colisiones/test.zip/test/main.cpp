#include <cstdlib>
#include <iostream>
//#include "../detector_colisiones.h"
#include "../simple/paralelepipedo.h"

using namespace std;
using namespace urjr;

class Cubo : virtual public Colisiones::Objeto::Paralelepipedo
{

	public:

		Punto3D
			centro_base;

		Longitud
			semilado;

		void base (Rectangulo *r)
		{
			r->x[MIN] = centro_base[X] - semilado;
			r->x[MAX] = centro_base[X] + semilado;
			r->y[MIN] = centro_base[Z] - semilado;
			r->y[MAX] = centro_base[Z] + semilado;
		}

		void altura (Intervalo &i)
		{
			i[MIN] = centro_base[Y];
			i[MAX] = centro_base[Y] + 2.0 * semilado;
		}
};

int main ()
{
	Coordenada
		ce1[3] = {0,0,0},
		ce2[3] = {2,2,3.0};

	Longitud
		sl1 = 1.0,
		sl2 = 2.0;

	Cubo c1, c2;

	c1.centro_base = ce1;
	c2.centro_base = ce2;
	c1.semilado = sl1;
	c2.semilado = sl2;

	cout << c1.colisiona_con(&c2);

	return 0;
}
