#include "../time.h"
#include <chrono>
#include <iostream>
#include <conio.h>

using namespace std;


int main()
{
	chrono::duration <double>
		d;
	chrono::high_resolution_clock::time_point
		t1,
		t2;
	time_t
		time,
		time1,
		time2;
	int ticks = 0;

	urjr::Time::Tick<int> t (2);

	_getch();

	t1 = chrono::high_resolution_clock::now();
	time = time1 = chrono::high_resolution_clock::to_time_t (t1);
	cout << time1 << endl << endl;

	while (!_kbhit())
	{
		t2 = chrono::high_resolution_clock::now();
		time2 = chrono::high_resolution_clock::to_time_t (t2);

		cout << "\r" << (time2 - time);
		if (t.tick (time2 - time1))
			ticks++;
		cout << " ticks: " << ticks;
		time1 = time2;
	}
	_getch();

	t2 = chrono::high_resolution_clock::now();
	time2 = chrono::high_resolution_clock::to_time_t (t2);
	cout << endl << endl << time2 << endl;
	
	
	urjr::Time::UniformIterator <double> ui;
	

	return 0;
}
