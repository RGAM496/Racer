#ifndef URJR_GLUT_KEYBOARD_H
#define URJR_GLUT_KEYBOARD_H

#include <GL/glut.h>


namespace urjr_glut
{
	namespace urjr
	{

		// Maneja los mensajes recibidos al pulsar o soltar teclas.
		class KeyboardHandler
		{
			public:
				void setOnKeyDownCallback ();
				void setOnKeyUpCallback ();
				void setOnSpecialKeyDownCallback ();
				void setOnSpecialKeyUpCallback ();
				void setKeyboardCallbacks ();
			private:
				virtual void onKeyDown (unsigned char key, int action);
				virtual void onKeyUp (unsigned char key, int action);
				virtual void onSpecialKeyDown (int key, int action);
				virtual void onSpecialKeyUp (int key, int action);
			friend class KeyboardSelector;
		};

		// Selecciona qué función se empleará para manejar el teclado.
		class KeyboardSelector
		{
			public:
				static void setOnKeyDownCallbackFunction (KeyboardHandler *kbh);
				static void setOnKeyUpCallbackFunction (KeyboardHandler *kbh);
				static void setOnSpecialKeyDownCallbackFunction (KeyboardHandler *kbh);
				static void setOnSpecialKeyUpCallbackFunction (KeyboardHandler *kbh);
				static void configure ();
			private:
				static KeyboardHandler *onKeyDownHandler;
				static KeyboardHandler *onKeyUpHandler;
				static KeyboardHandler *onSpecialKeyDownHandler;
				static KeyboardHandler *onSpecialKeyUpHandler;
				static void onKeyDownCallback (unsigned char key, int action);
				static void onKeyUpCallback (unsigned char key, int action);
				static void onSpecialKeyDownCallback (int key, int action);
				static void onSpecialKeyUpCallback (int key, int action);
		};

		// Manejador del teclado para una interfaz.
		class KeyboardInterface : public KeyboardHandler, public KeyboardSelector
		{
			public:
				static const unsigned int MAX_KEYS = GLFW_KEY_LAST + 1;
				bool is_down (unsigned int key);
				bool is_up (unsigned int key);
				bool operator [] (unsigned int); // Igual que key_down.
				KeyboardInterface ();
			private:
				bool keyDown[MAX_KEYS];
			protected:
				virtual void onKeyDown (unsigned char key, int action);
				virtual void onKeyUp (unsigned char key, int action);
				virtual void onSpecialKeyDown (int key, int action);
				virtual void onSpecialKeyUp (int key, int action);
		};

	}
}



#endif // URJR_GLUT_KEYBOARD_H
