#include <cstdlib>
#include <iostream>
#include <GL/glfw.h>
//#include "../objeto.h"
/*#include "../simple/obstaculo/cubo/objeto.h"
#include "../simple/obstaculo/piramide/objeto.h"
#include "../simple/obstaculo/cilindro/objeto.h"*/
#include "../simple/obstaculos.h"
#include "../generador_objetos.h"


using namespace std;
using namespace urjr;

ostream & operator << (ostream &os, const Punto3D &p)
{
	os << '(' << p[0] << ", " << p[1] << ", " << p[2] << ')';
	return os;
}


void dibujar_ejes (Punto3D p, double largo = 2)
{
	glBegin(GL_LINES);
		// Eje X.
		glColor3d (1,0,0);
		glVertex3d (p[X], p[Y], p[Z]);
		glVertex3d (p[X]+largo, p[Y], p[Z]);
		// Eje Y.
		glColor3d (0,1,0);
		glVertex3d (p[X], p[Y], p[Z]);
		glVertex3d (p[X], p[Y]+largo, p[Z]);
		// Eje Z.
		glColor3d (0,0,1);
		glVertex3d (p[X], p[Y], p[Z]);
		glVertex3d (p[X], p[Y], p[Z]+largo);
	glEnd();
}


void glTranslated (Punto3D p)
{
	glTranslated (p[X], p[Y], p[Z]);
}


int main ()
{
	bool running = true;

	if (!glfwInit ())
		exit (EXIT_FAILURE);


	Punto3D p = {2,1,-2.25};
	Longitud l = 2.5;

	urjr::Objeto::GeneradorObstaculo <urjr::Objeto::Simple::CuboVerde> cubo;
	urjr::Objeto::GeneradorObstaculo <urjr::Objeto::Simple::PiramideRoja> piramide;
	urjr::Objeto::GeneradorObstaculo <urjr::Objeto::Simple::CilindroAmarillo> cilindro;
	urjr::Objeto::GeneradorObstaculo <urjr::Objeto::Simple::EsferaAzul> esfera;
	urjr::Objeto::Simple::CuboVerde c, c1;
	urjr::Objeto::Simple::PiramideRoja pi;
	urjr::Objeto::Simple::CilindroAmarillo ci;
	urjr::Objeto::Simple::EsferaBlanca eb;
	urjr::Objeto::Simple::EsferaFucsia ef;
	urjr::Objeto::Simple::EsferaAzul ea;
	urjr::Objeto::Movil *pcu, *pci, *ppi, *pes;

	//p = {3,1,2};
	c.setPosicionCentral (p);
	//c.posicion_central ();
	c.semilado = l/2.0;
	p = {2,1,-0.5};
	c1.centro_base = p;
	c1.semilado = 1.0 / 2.0;

	pi.centro_base = {-1,1,2};
	pi.setPosicionCentral (pi.centro_base);
	pi.semilado = 0.5;
	pi.altura_actual = 2;

	ci.centro_base = {-2.0,1,2};
	ci.setPosicionCentral (ci.centro_base);
	ci.radio_base = 0.5;
	ci.altura_actual = 2.0;

	eb.centro_base = {3,-2,2};
	eb.radio_cuerpo = 0.5;

	ef.centro_base = {0,-2,2};
	ef.radio_cuerpo = 1.0;

	ea.centro_base = {-2,-2,2};
	ea.radio_cuerpo = 1.0;

	pcu = cubo.generate();
	pci = cilindro.generate();
	ppi = piramide.generate();
	pes = esfera.generate();
	//cout << "c2->centro = " << c2->posicion_central() << endl;

	pcu->setPosicionCentral ({0,0,5});
	pci->setPosicionCentral ({-1.5,0,5});
	ppi->setPosicionCentral ({0,0,6.5});
	pes->setPosicionCentral ({1.5,0,5});
	//cout << pcu->posicion_central () << endl;
	//p = pcu->posicion_central ();
	cout << "p = " << p << endl;
	pcu->getPosicionCentral (p);
	cout << "p = " << p << endl;



	cout
		<< c.centro_base << endl
		<< c.semilado * 2.0 << endl;

	/*if (c.colisiona_con(&c1))
		cout << "\tColisionan";
	else
		cout << "\tNo colisionan";
	cout << " los cubos.\n";

	if (colisionan (&c, &pi))
		cout << "\tColisionan";
	else
		cout << "\tNo colisionan";
	cout << " el primer cubo y la piramide.\n";

	if (colisionan (&c1, &ci))
		cout << "\tColisionan";
	else
		cout << "\tNo colisionan";
	cout << " el segundo cubo y el cilindro.\n";

	//cout << (ci.tipo_colision() == Colisiones::Forma::CILINDRO) << (pi.tipo_colision() == Colisiones::Forma::PIRAMIDE) << endl;
	if (colisionan (&ci, &pi))
		cout << "\tColisionan";
	else
		cout << "\tNo colisionan";
	cout << " el cilindro y la piramide.\n";

	if (colisionan (&ea, &ef))
		cout << "\tColisionan";
	else
		cout << "\tNo colisionan";
	cout << " las esferas azul y fucsia.\n";*/

	if (colisionan (pcu, pes))
		cout << "\tColisionan";
	else
		cout << "\tNo colisionan";
	cout << " el puntero al cubo y el puntero a la esfera.\n";

	if (pcu->colisiona_con(pes))
		cout << "\tColisionan";
	else
		cout << "\tNo colisionan";
	cout << " el puntero al cubo y el puntero al cilindro.\n";

	if (colisionan (pcu, ppi))
		cout << "\tColisionan";
	else
		cout << "\tNo colisionan";
	cout << " el puntero al cubo y el puntero a la piramide.\n";



	if (!glfwOpenWindow (1024,768, 0,0,0,0,0,0, GLFW_WINDOW))
	{
		glfwTerminate ();
		return EXIT_FAILURE;
	}
	glfwSetWindowPos (800, 100);

	const GLfloat light_ambient[]  = { 0.0f, 0.0f, 0.0f, 1.0f };
	const GLfloat light_diffuse[]  = { 1.0f, 1.0f, 1.0f, 1.0f };
	const GLfloat light_specular[] = { 1.0f, 1.0f, 1.0f, 1.0f };
	const GLfloat light_position[] = { 2.0f, 5.0f, 5.0f, 0.0f };

	const GLfloat mat_ambient[]    = { 0.7f, 0.7f, 0.7f, 1.0f };
	const GLfloat mat_diffuse[]    = { 0.8f, 0.8f, 0.8f, 1.0f };
	const GLfloat mat_specular[]   = { 1.0f, 1.0f, 1.0f, 1.0f };
	const GLfloat high_shininess[] = { 100.0f };

	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LESS);
	//glEnable(GL_BLEND);
	//glEnable(GL_LINE_SMOOTH);

	glEnable(GL_LIGHT0);
    glEnable(GL_NORMALIZE);
    glEnable(GL_COLOR_MATERIAL);
    glEnable(GL_LIGHTING);

    glLightfv(GL_LIGHT0, GL_AMBIENT,  light_ambient);
    glLightfv(GL_LIGHT0, GL_DIFFUSE,  light_diffuse);
    glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular);
    glLightfv(GL_LIGHT0, GL_POSITION, light_position);

    glMaterialfv(GL_FRONT, GL_AMBIENT,   mat_ambient);
    glMaterialfv(GL_FRONT, GL_DIFFUSE,   mat_diffuse);
    glMaterialfv(GL_FRONT, GL_SPECULAR,  mat_specular);
    glMaterialfv(GL_FRONT, GL_SHININESS, high_shininess);

	//urjr::Objeto::Simple::Cubo::Objeto::inicializar();
	cubo.inicializar();

	while (running)
	{
		glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		glMatrixMode( GL_PROJECTION );
        glLoadIdentity();
        //gluPerspective( 65.0f, (GLfloat)640/(GLfloat)480, 1.0f, 100.0f );
        const float ar = 1024.0 / 768.0;
        glViewport(0, 0, 1024.0, 768.0);
        glFrustum(-ar, ar, -1.0, 1.0, 2.0, 100.0);

        glMatrixMode( GL_MODELVIEW );
        glLoadIdentity();
        gluLookAt(5.0f, 4.0f, 12.0f,
                0.0f, 0.0f, 0.0f,
                0.0f, 1.0f, 0.0f );
		//glTranslated (0.0, -2.0, 0.0);

		Punto3D origen_coordenadas = {0,0,0};
		dibujar_ejes (origen_coordenadas, 5);

		Punto3D pc2;

		glPushMatrix();
			dibujar_ejes(c.centro_base);
			glTranslated (c.centro_base);
			c.dibujar ();
		glPopMatrix();

		glPushMatrix();
			dibujar_ejes(c1.centro_base);
			glTranslated (c1.centro_base);
			c1.dibujar ();
		glPopMatrix();

		glPushMatrix();
			dibujar_ejes(pi.centro_base);
			glTranslated (pi.centro_base);
			pi.dibujar ();
		glPopMatrix();

		glPushMatrix();
			dibujar_ejes(ci.centro_base);
			glTranslated (ci.centro_base);
			ci.dibujar ();
		glPopMatrix();

		glPushMatrix();
			dibujar_ejes(eb.centro_base);
			glTranslated (eb.centro_base);
			eb.dibujar ();
		glPopMatrix();

		/*glPushMatrix();
			dibujar_ejes(ef.centro_base);
			glTranslated (ef.centro_base);
			ef.dibujar ();
		glPopMatrix();

		glPushMatrix();
			dibujar_ejes(ea.centro_base);
			glTranslated (ea.centro_base);
			ea.dibujar ();
		glPopMatrix();*/

		glPushMatrix();
			pcu->getPosicionCentral (pc2);
			dibujar_ejes(pc2);
			glTranslated (pc2);
			pcu->dibujar ();
		glPopMatrix();

		glPushMatrix();
			pes->getPosicionCentral (pc2);
			dibujar_ejes(pc2);
			glTranslated (pc2);
			pes->dibujar ();
		glPopMatrix();

		glPushMatrix();
			pci->getPosicionCentral (pc2);
			dibujar_ejes(pc2);
			glTranslated (pc2);
			pci->dibujar ();
		glPopMatrix();

		glPushMatrix();
			ppi->getPosicionCentral (pc2);
			dibujar_ejes(pc2);
			glTranslated (pc2);
			ppi->dibujar ();
		glPopMatrix();

		glfwSwapBuffers ();

		running = !glfwGetKey (GLFW_KEY_ESC) && glfwGetWindowParam (GLFW_OPENED);
	}

	//urjr::Objeto::Simple::Cubo::Objeto::finalizar();
	cubo.finalizar();
	delete pcu;
	delete pci;
	delete ppi;
	delete pes;

	glfwTerminate ();

	return EXIT_SUCCESS;
}
