#include "../random_generator.h"
#include <conio.h>
#include <iostream>

#define imprimir() \
std::cout << dmin << " - " << dmax << "\t(" << (dmin - 0.0) << ", " << (1.0 - dmax) << ")\n"


int main()
{
	std::default_random_engine generator;
	urjr::RandomGenerator::UniformReal <double> ur(0,1);
	int k = '\0';
	double d, dmin, dmax;

	urjr::RandomGenerator::time_seed (generator);

	dmin = dmax = d = d = ur(generator);
	imprimir();
	do
	{
		if (_kbhit())
			k = _getch();
		d = ur(generator);
		if (d < dmin) {
			dmin = d;
			imprimir();
		}
		else if (d > dmax) {
			dmax = d;
			imprimir();
		}
	}
	while (k != 27);

	return 0;
}
