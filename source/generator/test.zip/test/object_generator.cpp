#include "../class_generator.h"
#include <cstdlib>
#include <iostream>
#include <vector>

using namespace urjr;


class A {
	public:
		virtual void print() = 0;
		//virtual void print() {std::cout "Algo\n";}
};

class B : public A {
	public:
		void print() {std::cout << "Hola\n";}
};

class C : public A {
	public:
		void print() {std::cout << "Chau\n";}
};


typedef A* (*A_GEN)(void);


void print(A &a)
{
	a.print();
}


int main()
{
    ClassGenerator::Instance<B,A> bGen;
    ClassGenerator::Instance<C,A> cGen;
    //A_GEN aGen[] = {new_dynamic<B>, new_dynamic<C>};
    ClassGenerator::Interface<A> *aGen[] = {&bGen, &cGen};
    A *pab = aGen[0]->generate();
    //ab = *bGen;
    pab->print();
    delete pab;
    pab = aGen[1]->generate();
    pab->print();
    delete pab;

    std::vector<ClassGenerator::Interface<A>*> vecA;
    vecA.push_back(&bGen);
    vecA.push_back(&cGen);
    pab = vecA[0]->generate();
    pab->print();
    delete pab;
    pab = vecA[1]->generate();
    pab->print();
    delete pab;

    B baseB;
    A &baseA = baseB;
    print(baseB);
    print(baseA);
    //print(C());

	system("pause");
	return 0;
}
