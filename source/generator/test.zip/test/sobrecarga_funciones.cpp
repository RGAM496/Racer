#include <cstdlib>
#include <iostream>


class A {
	public:
		virtual void print() = 0;
		//virtual void print() {std::cout "Algo\n";}
};

class B : public A {
	public:
		void print() {std::cout << "Hola\n";}
};

class C : public A {
	public:
		void print() {std::cout << "Chau\n";}
};



void print (A *a1, A *a2);
void print (B *b, C *c);
void prints (B *b, C *c);



void print (A *a1, A *a2)
{
	std::cout << "\nA & A\n";
	a1->print();
	a2->print();
	system("pause");
	prints ((B*)a1, (C*)a2);
}


void print (B *b, C *c)
{
	std::cout << "\nB & C\n";
	b->print();
	c->print();
}


void prints (B *b, C *c)
{
	print (c, b);
}




int main()
{
	B b;
	C c;
	A *ab, *ac;
	
	ab = &b;
	ac = &c;
	print(ab, ac);
	print(&b, &c);
	print((A*)&b, (A*)&c);
	print(&c, &b);
	
	system("pause");
	return 0;
}
